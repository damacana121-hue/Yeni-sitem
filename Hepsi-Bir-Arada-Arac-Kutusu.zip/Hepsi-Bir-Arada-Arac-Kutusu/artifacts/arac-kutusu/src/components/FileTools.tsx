import { useState } from 'react';
import { FileText, Files, Scissors, Trash2, Image as ImageIcon, FileOutput } from 'lucide-react';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { Button, FilePicker, Status, ToolCard, TextInput, DownloadLink } from './shared';
import { PdfCanvasEditor } from './PdfCanvasEditor';

type DownloadItem = { name: string; url: string };
const saveBlob = (blob: Blob, name: string): DownloadItem => ({ name, url: URL.createObjectURL(blob) });
const binaryBuffer = (bytes: Uint8Array) => {
  const buffer = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(buffer).set(bytes);
  return buffer;
};
async function renderPdfPages(file: File, type: 'image/png' | 'image/jpeg') {
  const pdfjs = await import('pdfjs-dist');
  pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;
  const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
  const output: DownloadItem[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i); const viewport = page.getViewport({ scale: 1.7 });
    const canvas = document.createElement('canvas'); canvas.width = viewport.width; canvas.height = viewport.height;
    await page.render({ canvas, canvasContext: canvas.getContext('2d')!, viewport }).promise;
    const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((b) => b ? resolve(b) : reject(new Error('Sayfa görsele dönüştürülemedi.')), type));
    output.push(saveBlob(blob, `${file.name.replace(/\.pdf$/i, '')}-sayfa-${i}.${type.endsWith('png') ? 'png' : 'jpg'}`));
  }
  return output;
}
async function extractPdfText(file: File) {
  const pdfjs = await import('pdfjs-dist');
  pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;
  const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
  const pages: string[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i); const content = await page.getTextContent();
    pages.push(content.items.map((item) => 'str' in item ? item.str : '').join(' '));
  }
  return pages;
}
async function textToPdf(text: string, name: string) {
  const { PDFDocument, StandardFonts, rgb } = await import('pdf-lib');
  const doc = await PDFDocument.create(); const font = await doc.embedFont(StandardFonts.Helvetica);
  const lines = text.replace(/\r/g, '').split('\n'); let page = doc.addPage([595, 842]); let y = 792;
  for (const line of lines) {
    const wrapped = line.match(/.{1,88}(\s|$)/g) || [line];
    for (const part of wrapped) {
      if (y < 48) { page = doc.addPage([595, 842]); y = 792; }
      page.drawText(part.trimEnd(), { x: 48, y, size: 10, font, color: rgb(.12, .19, .18), maxWidth: 500 }); y -= 15;
    }
  }
  return saveBlob(new Blob([binaryBuffer(await doc.save())], { type: 'application/pdf' }), name);
}
export function FileTools() {
  const [files, setFiles] = useState<File[]>([]);
  const [output, setOutput] = useState<DownloadItem[]>([]);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [working, setWorking] = useState(false);
  const [range, setRange] = useState('1');
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [splitFile, setSplitFile] = useState<File | null>(null);

  const run = async (fn: () => Promise<DownloadItem[]>) => {
    setWorking(true); setError(''); setStatus(''); setOutput([]);
    try { const items = await fn(); setOutput(items); setStatus(`${items.length} dosya hazır. İndirip kontrol edebilirsin.`); }
    catch (e) { setError(e instanceof Error ? e.message : 'İşlem tamamlanamadı. Dosya biçimini ve içeriğini kontrol et.'); }
    finally { setWorking(false); }
  };
  const merge = () => run(async () => {
    const { PDFDocument } = await import('pdf-lib');
    if (files.length < 2) throw new Error('Birleştirmek için en az iki PDF seç.');
    const merged = await PDFDocument.create();
    for (const f of files) { const source = await PDFDocument.load(await f.arrayBuffer()); const pages = await merged.copyPages(source, source.getPageIndices()); pages.forEach((p) => merged.addPage(p)); }
    return [saveBlob(new Blob([binaryBuffer(await merged.save())], { type: 'application/pdf' }), 'birlesik-belge.pdf')];
  });
  const split = () => run(async () => {
    const { PDFDocument } = await import('pdf-lib');
    if (!splitFile) throw new Error('Bölünecek PDF dosyasını seç.');
    const src = await PDFDocument.load(await splitFile.arrayBuffer()); const indices = range.split(',').flatMap((part) => {
      const [a, b = a] = part.trim().split('-').map(Number);
      if (!Number.isInteger(a) || !Number.isInteger(b) || a < 1 || b < a || b > src.getPageCount()) throw new Error(`Sayfa aralığı 1–${src.getPageCount()} arasında olmalı.`);
      return Array.from({ length: b - a + 1 }, (_, i) => a - 1 + i);
    });
    if (indices.length > 40) throw new Error('Bir seferde en fazla 40 sayfa aralığı çıkar.');
    const results: DownloadItem[] = [];
    for (const index of indices) { const dest = await PDFDocument.create(); const [page] = await dest.copyPages(src, [index]); dest.addPage(page); results.push(saveBlob(new Blob([binaryBuffer(await dest.save())], { type: 'application/pdf' }), `sayfa-${index + 1}.pdf`)); }
    return results;
  });
  const cleanMeta = () => run(async () => {
    const { PDFDocument } = await import('pdf-lib');
    const file = splitFile || files[0]; if (!file) throw new Error('Metadata bilgisi temizlenecek PDF dosyasını seç.');
    const source = await PDFDocument.load(await file.arrayBuffer()); const cleaned = await PDFDocument.create();
    const pages = await cleaned.copyPages(source, source.getPageIndices()); pages.forEach((p) => cleaned.addPage(p));
    return [saveBlob(new Blob([binaryBuffer(await cleaned.save())], { type: 'application/pdf' }), `${file.name.replace(/\.pdf$/i, '')}-temiz.pdf`)];
  });
  const imagesPdf = () => run(async () => {
    const { PDFDocument } = await import('pdf-lib');
    if (!imageFiles.length) throw new Error('PDF oluşturmak için görsel dosyaları seç.');
    const pdf = await PDFDocument.create();
    for (const f of imageFiles) {
      const bytes = await f.arrayBuffer(); const img = f.type === 'image/png' ? await pdf.embedPng(bytes) : await pdf.embedJpg(bytes);
      const page = pdf.addPage([img.width, img.height]); page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });
    }
    return [saveBlob(new Blob([binaryBuffer(await pdf.save())], { type: 'application/pdf' }), 'gorseller.pdf')];
  });
  const docxToPdf = () => run(async () => {
    if (!files[0] || !/\.docx$/i.test(files[0].name)) throw new Error('Bir DOCX dosyası seçmelisin.');
    const mammoth = await import('mammoth'); const result = await mammoth.extractRawText({ arrayBuffer: await files[0].arrayBuffer() });
    if (!result.value.trim()) throw new Error('DOCX içinden metin okunamadı.');
    return [await textToPdf(result.value, 'belge-metni.pdf')];
  });
  const pdfToDocx = () => run(async () => {
    const { Document, Packer, Paragraph } = await import('docx');
    const f = files[0]; if (!f || !/\.pdf$/i.test(f.name)) throw new Error('Metni çıkarılacak PDF dosyasını seç.');
    const pages = await extractPdfText(f); const paragraphs = pages.flatMap((text) => [new Paragraph({ text }), new Paragraph({ text: '' })]);
    const doc = new Document({ sections: [{ children: paragraphs }] }); const blob = await Packer.toBlob(doc);
    return [saveBlob(blob, 'cikarilan-metin.docx')];
  });
  const pdfImages = (type: 'image/png' | 'image/jpeg') => run(async () => {
    const f = splitFile || files[0]; if (!f || !/\.pdf$/i.test(f.name)) throw new Error('Sayfaları görsele çevrilecek PDF dosyasını seç.');
    return renderPdfPages(f, type);
  });
  return <section className="category-block" data-testid="section-file-tools">
    <div className="category-title"><span className="category-number">02</span><div><h3>Akıllı Dosya Araçları</h3><p>PDF ve DOCX işlemlerini yerel olarak yap; dosyaların cihazından çıkmasın.</p></div><span className="category-tag">BELGE</span></div>
    <PdfCanvasEditor />
    <div className="file-grid">
      <ToolCard title="Görsellerden PDF" description="Her görsel ayrı bir PDF sayfası olur" icon={<ImageIcon size={17} />}>
        <FilePicker accept="image/png,image/jpeg" multiple onChange={(list) => setImageFiles(Array.from(list || []))} label="JPG veya PNG seç" />
        <div className="selected-files">{imageFiles.map((f, i) => <span key={f.name + i}>{f.name}</span>)}</div>
        <Button onClick={imagesPdf} disabled={working} testId="button-images-to-pdf"><FileOutput size={15} /> PDF oluştur</Button>
      </ToolCard>
      <ToolCard title="PDF sayfalarını görsele" description="Her sayfayı ayrı PNG veya JPG olarak al" icon={<FileOutput size={17} />}>
        <FilePicker accept="application/pdf,.pdf" onChange={(list) => setSplitFile(list?.[0] || null)} label="PDF seç" />
        {splitFile && <p className="selected-file">{splitFile.name}</p>}
        <div className="button-pair"><Button variant="secondary" onClick={() => pdfImages('image/png')} disabled={working}>PNG çıkar</Button><Button variant="secondary" onClick={() => pdfImages('image/jpeg')} disabled={working}>JPG çıkar</Button></div>
      </ToolCard>
      <ToolCard title="PDF birleştir" description="Birden fazla dosyanın sayfalarını sırayla birleştir" icon={<Files size={17} />}>
        <FilePicker accept="application/pdf,.pdf" multiple onChange={(list) => setFiles(Array.from(list || []))} label="PDF dosyalarını seç" />
        <div className="selected-files">{files.map((f, i) => <span key={f.name + i}>{i + 1}. {f.name}</span>)}</div>
        <Button onClick={merge} disabled={working} testId="button-pdf-merge"><Files size={15} /> PDF’leri birleştir</Button>
      </ToolCard>
      <ToolCard title="Sayfaları ayır" description="Sayfa numarası veya aralığı ver; örn. 1, 3-5" icon={<Scissors size={17} />}>
        <FilePicker accept="application/pdf,.pdf" onChange={(list) => setSplitFile(list?.[0] || null)} label="PDF seç" />
        {splitFile && <p className="selected-file">{splitFile.name}</p>}
        <TextInput label="Sayfa numarası / aralığı" value={range} onChange={setRange} placeholder="1, 3-5" testId="input-pdf-range" />
        <div className="button-pair"><Button onClick={split} disabled={working} testId="button-pdf-split"><Scissors size={15} /> Sayfaları çıkar</Button><Button variant="quiet" onClick={cleanMeta} disabled={working} testId="button-pdf-clean"><Trash2 size={15} /> Metadata temizle</Button></div>
        <p className="micro-note">Metadata temizleme sayfaları yeniden oluşturur; dijital imzalar korunmaz.</p>
      </ToolCard>
      <ToolCard title="DOCX ve PDF" description="Metni çıkararak biçimi sadeleştirilmiş dönüşüm yapar" icon={<FileText size={17} />}>
        <FilePicker accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,.pdf" onChange={(list) => setFiles(Array.from(list || []))} label="DOCX veya PDF seç" />
        {files[0] && <p className="selected-file">{files[0].name}</p>}
        <div className="button-pair"><Button variant="secondary" onClick={docxToPdf} disabled={working}>DOCX → PDF</Button><Button variant="secondary" onClick={pdfToDocx} disabled={working}>PDF → DOCX</Button></div>
        <p className="micro-note">DOCX → PDF yalnızca metni aktarır; özgün düzen ve görseller korunmayabilir. PDF → DOCX metni çıkarır, taranmış sayfalarda OCR yoktur.</p>
      </ToolCard>
    </div>
    {(error || status) && <div className="global-status">{error ? <Status message={error} kind="error" /> : <Status message={status} kind="success" />}</div>}
    {!!output.length && <div className="outputs" data-testid="list-file-outputs"><b>İşlem çıktısı</b>{output.map((item) => <div className="output-item" key={item.name}><span><FileText size={15} />{item.name}</span><DownloadLink href={item.url} name={item.name} /></div>)}</div>}
    {working && <Status message="Dosya tarayıcıda işleniyor…" kind="working" />}
  </section>;
}
