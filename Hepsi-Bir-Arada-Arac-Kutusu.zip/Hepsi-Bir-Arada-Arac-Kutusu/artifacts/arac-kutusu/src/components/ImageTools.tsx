import { useEffect, useRef, useState, type MouseEvent } from 'react';
import { Image as ImageIcon, Crop, Scaling, Eraser, RotateCcw, Download, Upload, SlidersHorizontal } from 'lucide-react';
import { Button, FilePicker, Status, ToolCard, TextInput, DownloadLink } from './shared';

type ImageFile = { file: File; url: string; width: number; height: number };
export function ImageTools() {
  const [image, setImage] = useState<ImageFile | null>(null);
  const [result, setResult] = useState<{ url: string; name: string; bytes: number } | null>(null);
  const [width, setWidth] = useState('800');
  const [height, setHeight] = useState('600');
  const [quality, setQuality] = useState('0.82');
  const [format, setFormat] = useState('image/webp');
  const [tolerance, setTolerance] = useState('32');
  const [sample, setSample] = useState<[number, number, number] | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const previewRef = useRef<HTMLImageElement>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => () => { if (image) URL.revokeObjectURL(image.url); }, [image]);
  useEffect(() => () => { if (result) URL.revokeObjectURL(result.url); }, [result]);

  const choose = (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { setError('Lütfen geçerli bir görsel dosyası seç.'); return; }
    setError(''); setMessage(''); setResult(null); setSample(null);
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { setImage({ file, url, width: img.naturalWidth, height: img.naturalHeight }); setWidth(String(img.naturalWidth)); setHeight(String(img.naturalHeight)); };
    img.onerror = () => setError('Görsel açılamadı. Başka bir dosya deneyin.');
    img.src = url;
  };
  const canvasFor = async (): Promise<HTMLCanvasElement> => {
    if (!image) throw new Error('Önce bir görsel seç.');
    const img = new Image(); img.src = image.url; await img.decode();
    const canvas = document.createElement('canvas'); canvas.width = img.naturalWidth; canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d', { willReadFrequently: true }); if (!ctx) throw new Error('Bu tarayıcı canvas işlemini desteklemiyor.');
    ctx.drawImage(img, 0, 0); return canvas;
  };
  const finish = (canvas: HTMLCanvasElement, type = format, qualityValue = Number(quality), suffix?: string) => new Promise<void>((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) { reject(new Error('Bu biçime dönüştürme başarısız oldu.')); return; }
      const ext = type === 'image/jpeg' ? 'jpg' : type === 'image/png' ? 'png' : 'webp';
      const stem = image?.file.name.replace(/\.[^.]+$/, '') || 'gorsel';
      const url = URL.createObjectURL(blob); setResult({ url, name: `${stem}${suffix ? `-${suffix}` : ''}.${ext}`, bytes: blob.size });
      setError(''); setMessage(`Hazır: ${(blob.size / 1024).toFixed(1)} KB · metadata yeniden kodlamayla kaldırıldı.`); resolve();
    }, type, type === 'image/png' ? undefined : qualityValue);
  });
  const act = async (operation: 'resize' | 'avatar' | 'remove-bg' | 'encode') => {
    setError(''); setMessage(''); setBusy(true);
    try {
      const canvas = await canvasFor(); const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
      if (operation === 'resize') {
        const w = Number(width), h = Number(height);
        if (!Number.isInteger(w) || !Number.isInteger(h) || w < 1 || h < 1 || w > 12000 || h > 12000) throw new Error('Genişlik ve yükseklik 1–12.000 piksel arasında olmalı.');
        const resized = document.createElement('canvas'); resized.width = w; resized.height = h;
        resized.getContext('2d')!.drawImage(canvas, 0, 0, w, h); await finish(resized, format, Number(quality), 'boyutlandirilmis');
      } else if (operation === 'avatar') {
        const side = Math.min(canvas.width, canvas.height);
        const output = document.createElement('canvas'); output.width = side; output.height = side;
        const out = output.getContext('2d')!; out.beginPath(); out.arc(side / 2, side / 2, side / 2, 0, Math.PI * 2); out.clip();
        out.drawImage(canvas, (canvas.width - side) / 2, (canvas.height - side) / 2, side, side, 0, 0, side, side);
        await finish(output, 'image/png', 1, 'avatar');
      } else if (operation === 'remove-bg') {
        if (!sample) throw new Error('Önizlemede arka plan renginden bir noktaya tıkla.');
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height); const [r, g, b] = sample; const tol = Number(tolerance);
        for (let i = 0; i < data.data.length; i += 4) {
          const d = Math.sqrt((data.data[i] - r) ** 2 + (data.data[i + 1] - g) ** 2 + (data.data[i + 2] - b) ** 2);
          if (d <= tol * 2.7) data.data[i + 3] = 0;
          else if (d <= tol * 4) data.data[i + 3] = Math.round(data.data[i + 3] * (d - tol * 2.7) / (tol * 1.3));
        }
        ctx.putImageData(data, 0, 0); await finish(canvas, 'image/png', 1, 'seffaf');
      } else {
        if (format === 'image/jpeg') { ctx.globalCompositeOperation = 'destination-over'; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height); }
        await finish(canvas, format, Number(quality), 'donusturulmus');
      }
    } catch (e) { setError(e instanceof Error ? e.message : 'İşlem tamamlanamadı.'); }
    finally { setBusy(false); }
  };
  const sampleAt = (event: MouseEvent<HTMLImageElement>) => {
    if (!image || !previewRef.current) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = Math.floor((event.clientX - rect.left) * image.width / rect.width), y = Math.floor((event.clientY - rect.top) * image.height / rect.height);
    const canvas = document.createElement('canvas'); canvas.width = image.width; canvas.height = image.height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true })!; const img = new Image(); img.src = image.url;
    img.onload = () => { ctx.drawImage(img, 0, 0); const p = ctx.getImageData(x, y, 1, 1).data; setSample([p[0], p[1], p[2]]); };
  };
  const rgb = sample ? `rgb(${sample.join(', ')})` : '';

  return <section className="category-block" data-testid="section-image-tools">
    <div className="category-title"><span className="category-number">01</span><div><h3>Görsel Temizleme Merkezi</h3><p>Görseli yükle, istediğin sonuca birkaç dokunuşta ulaş.</p></div><span className="category-tag">GÖRSEL</span></div>
    <div className="image-workspace">
      <ToolCard title="Görselini hazırla" description="JPG, PNG veya WebP · dosya cihazında işlenir" icon={<ImageIcon size={17} />} className="image-main-card">
          {!image ? <div className="upload-zone" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); choose(e.dataTransfer.files); }}><div className="upload-emblem"><Upload size={22} /></div><b>Görselini buraya bırak</b><span>veya cihazından bir dosya seç</span><FilePicker accept="image/*" onChange={choose} label="Görsel seç" /></div> :
          <div className="image-preview-wrap">
            <div className="preview-topline"><span><b>{image.file.name}</b><small>{image.width} × {image.height} px · {(image.file.size / 1024).toFixed(1)} KB</small></span><button className="text-button" onClick={() => { setImage(null); setResult(null); setMessage(''); }} data-testid="button-image-reset"><RotateCcw size={14} /> Başka görsel seç</button></div>
            <div className="preview-stage"><img ref={previewRef} src={image.url} alt="Yüklenen görsel önizlemesi" onClick={sampleAt} title="Arka plan rengi seçmek için tıkla" data-testid="img-preview" /></div>
            {result && <div className="result-line"><span className="result-check"><Download size={14} /></span><span><b>{result.name}</b><small>{(result.bytes / 1024).toFixed(1)} KB</small></span><DownloadLink href={result.url} name={result.name} /></div>}
          </div>}
        {error && <Status message={error} kind="error" />}{message && <Status message={message} />}
      </ToolCard>
      <ToolCard title="Hızlı düzenleme" description="Boyut, biçim ve dosya ağırlığını ayarla" icon={<SlidersHorizontal size={17} />}>
        <div className="field-row"><TextInput label="Genişlik (px)" value={width} onChange={setWidth} type="number" min={1} testId="input-image-width" /><TextInput label="Yükseklik (px)" value={height} onChange={setHeight} type="number" min={1} testId="input-image-height" /></div>
        <Button onClick={() => act('resize')} disabled={!image || busy} testId="button-image-resize"><Scaling size={15} /> Boyutlandır</Button>
        <div className="divider-label">DIŞA AKTAR</div>
        <label className="field"><span>Dosya biçimi</span><select value={format} onChange={(e) => setFormat(e.target.value)} data-testid="select-image-format"><option value="image/webp">WebP</option><option value="image/jpeg">JPG</option><option value="image/png">PNG</option></select></label>
        <label className="field"><span>Sıkıştırma kalitesi <b>{Math.round(Number(quality) * 100)}%</b></span><input type="range" min="0.1" max="1" step="0.01" value={quality} onChange={(e) => setQuality(e.target.value)} data-testid="input-image-quality" /></label>
        <Button variant="secondary" onClick={() => act('encode')} disabled={!image || busy} testId="button-image-convert"><Download size={15} /> Dönüştür ve sıkıştır</Button>
        <p className="micro-note">Yeniden kodlama, desteklenen görsel metadata bilgilerini temizler.</p>
      </ToolCard>
      <ToolCard title="Profil fotoğrafı" description="Görselini daire biçiminde kırp, şeffaf PNG indir" icon={<Crop size={17} />}>
        <div className="avatar-demo"><span className="avatar-circle">{image && <img src={image.url} alt="" />}</span><span className="avatar-arrow">→</span><span className="avatar-result"><ImageIcon size={17} /></span></div>
        <p className="tool-hint">Görselin merkezindeki kare alan kullanılır; daire dışı şeffaf kalır.</p>
        <Button onClick={() => act('avatar')} disabled={!image || busy} testId="button-image-avatar"><Crop size={15} /> Dairesel avatar oluştur</Button>
      </ToolCard>
      <ToolCard title="Düz arka planı temizle" description="Tek renkli fonlar için yaklaşık saydamlaştırma" icon={<Eraser size={17} />}>
        <div className="sample-pick"><span className="sample-swatch" style={{ background: rgb || 'repeating-conic-gradient(#ddd 0% 25%, #fff 0% 50%) 50% / 12px 12px' }} />{sample ? <span>Seçilen renk <b className="mono">{rgb}</b></span> : <span>Yukarıdaki önizlemede fona tıkla</span>}</div>
        <label className="field"><span>Renk toleransı <b>{tolerance}</b></span><input type="range" min="1" max="100" value={tolerance} onChange={(e) => setTolerance(e.target.value)} data-testid="input-image-tolerance" /></label>
        <div className="limitation-note"><b>Sınırlama</b><span>Bu araç örneklenen düz renge yakın pikselleri saydamlaştırır. Karmaşık fonları, gölgeleri veya saç kenarlarını yapay zekâ ile ayırmaz.</span></div>
        <Button variant="secondary" onClick={() => act('remove-bg')} disabled={!image || busy} testId="button-image-remove-bg"><Eraser size={15} /> Saydam PNG oluştur</Button>
      </ToolCard>
    </div>
  </section>;
}
