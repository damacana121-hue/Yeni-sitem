import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { ChevronLeft, ChevronRight, Download, FilePlus2, ImagePlus, Minus, Plus, Redo2, RectangleHorizontal, RotateCcw, Type, Undo2, X } from 'lucide-react';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { Button, Status } from './shared';

type Overlay = {
  id: string;
  page: number;
  kind: 'text' | 'shape' | 'image';
  x: number;
  y: number;
  w: number;
  h: number;
  text?: string;
  fontSize?: number;
  color: string;
  fill: string;
  imageData?: string;
};
type HistoryItem = Overlay[];
type PdfPage = { rotate?: number; getViewport: (options: { scale: number }) => { width: number; height: number }; render: (options: { canvas: HTMLCanvasElement; canvasContext: CanvasRenderingContext2D; viewport: { width: number; height: number } }) => { promise: Promise<void>; cancel: () => void } };
const colorRgb = (hex: string) => {
  const value = hex.replace('#', '');
  return { r: parseInt(value.slice(0, 2), 16) / 255, g: parseInt(value.slice(2, 4), 16) / 255, b: parseInt(value.slice(4, 6), 16) / 255 };
};
const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
const dataUrlBytes = (value: string) => Uint8Array.from(atob(value.split(',')[1]), (char) => char.charCodeAt(0));
const inputTarget = (target: EventTarget | null) => target instanceof HTMLElement && (!!target.closest('input, textarea, select, button, [contenteditable="true"]'));

function rasterizeText(item: Overlay, pageWidth: number, pageHeight: number) {
  const scale = 3;
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.ceil(item.w * pageWidth * scale));
  canvas.height = Math.max(1, Math.ceil(item.h * pageHeight * scale));
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Metin görsele aktarılamadı.');
  context.scale(scale, scale);
  context.fillStyle = item.color;
  context.textBaseline = 'top';
  context.font = `500 ${item.fontSize || 24}px "DM Sans", "Noto Sans", sans-serif`;
  const lineHeight = (item.fontSize || 24) * 1.22;
  const maxWidth = item.w * pageWidth - 6;
  let y = 2;
  for (const paragraph of (item.text || '').split('\n')) {
    const words = paragraph.split(/\s+/);
    let line = '';
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (line && context.measureText(candidate).width > maxWidth) {
        context.fillText(line, 2, y, maxWidth);
        y += lineHeight;
        line = word;
      } else line = candidate;
    }
    if (line) context.fillText(line, 2, y, maxWidth);
    y += lineHeight;
  }
  return canvas.toDataURL('image/png');
}

function exportPosition(item: Overlay, width: number, height: number, rotation: number) {
  const x = item.x * width;
  const yTop = item.y * height;
  const w = item.w * width;
  const h = item.h * height;
  const angle = ((rotation % 360) + 360) % 360;
  if (angle === 90) return { x: width * (1 - item.y - item.h), y: height * (1 - item.x - item.w), width: h, height: w };
  if (angle === 180) return { x: width - x - w, y: height * (1 - item.y - item.h), width: w, height: h };
  if (angle === 270) return { x: width * item.y, y: height * item.x, width: h, height: w };
  return { x, y: height - yTop - h, width: w, height: h };
}

export function PdfCanvasEditor() {
  const [file, setFile] = useState<File | null>(null);
  const [pageCount, setPageCount] = useState(0);
  const [pageIndex, setPageIndex] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [stageWidth, setStageWidth] = useState(700);
  const [stageHeight, setStageHeight] = useState(0);
  const [objects, setObjects] = useState<Overlay[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [past, setPast] = useState<HistoryItem[]>([]);
  const [future, setFuture] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [pdfPage, setPdfPage] = useState<PdfPage | null>(null);
  const [pageDimensions, setPageDimensions] = useState({ width: 0, height: 0, rotation: 0 });
  const stageHost = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const imageInput = useRef<HTMLInputElement>(null);
  const renderTask = useRef<{ cancel: () => void } | null>(null);
  const selected = objects.find((item) => item.id === selectedId) || null;
  const pageObjects = objects.filter((item) => item.page === pageIndex);

  useEffect(() => {
    const element = stageHost.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => {
      const width = entries[0]?.contentRect.width || 700;
      setStageWidth(Math.max(180, width - 36));
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!file) return;
    let active = true;
    setLoading(true);
    setError('');
    setPdfPage(null);
    setPageCount(0);
    setPageIndex(0);
    setStageHeight(0);
    const load = async () => {
      try {
        const pdfjs = await import('pdfjs-dist');
        pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;
        const document = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
        if (!active) return;
        setPageCount(document.numPages);
        const firstPage = await document.getPage(1);
        if (!active) return;
        setPdfPage(firstPage as unknown as PdfPage);
      } catch (cause) {
        if (active) setError(cause instanceof Error ? cause.message : 'PDF açılamadı. Dosyanın geçerli olduğundan emin ol.');
      } finally {
        if (active) setLoading(false);
      }
    };
    void load();
    return () => { active = false; renderTask.current?.cancel(); };
  }, [file]);

  useEffect(() => {
    if (!file || !pageCount) return;
    let active = true;
    setLoading(true);
    setError('');
    const loadPage = async () => {
      try {
        const pdfjs = await import('pdfjs-dist');
        pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;
        const document = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
        const page = await document.getPage(pageIndex + 1);
        if (active) setPdfPage(page as unknown as PdfPage);
      } catch (cause) {
        if (active) setError(cause instanceof Error ? cause.message : 'Sayfa yüklenemedi.');
      } finally {
        if (active) setLoading(false);
      }
    };
    void loadPage();
    return () => { active = false; renderTask.current?.cancel(); };
  }, [file, pageIndex, pageCount]);

  useEffect(() => {
    if (!pdfPage || !canvasRef.current) return;
    const base = pdfPage.getViewport({ scale: 1 });
    const scale = Math.max(0.15, (Math.min(stageWidth, 920) / base.width) * zoom);
    const viewport = pdfPage.getViewport({ scale });
    const canvas = canvasRef.current;
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    setStageHeight(viewport.height);
    setPageDimensions({ width: base.width, height: base.height, rotation: pdfPage.rotate || 0 });
    const context = canvas.getContext('2d');
    if (!context) return;
    try {
      const task = pdfPage.render({ canvas, canvasContext: context, viewport });
      renderTask.current = task;
      void task.promise.catch((cause: unknown) => {
        if (!(cause instanceof Error && cause.name === 'RenderingCancelledException')) setError('PDF sayfası çizilemedi.');
      });
    } catch {
      setError('PDF sayfası çizilemedi.');
    }
    return () => { renderTask.current?.cancel(); };
  }, [pdfPage, stageWidth, zoom]);

  const commit = useCallback((next: Overlay[]) => {
    setPast((history) => [...history.slice(-39), objects]);
    setFuture([]);
    setObjects(next);
  }, [objects]);

  const updateObject = useCallback((id: string, updates: Partial<Overlay>, record = true) => {
    const next = objects.map((item) => item.id === id ? { ...item, ...updates } : item);
    if (record) commit(next);
    else setObjects(next);
  }, [commit, objects]);

  const addObject = (kind: Overlay['kind'], imageData?: string) => {
    const item: Overlay = {
      id: makeId(), page: pageIndex, kind, x: 0.12, y: 0.14,
      w: kind === 'text' ? 0.38 : 0.3, h: kind === 'text' ? 0.11 : 0.18,
      text: kind === 'text' ? 'Metninizi yazın' : undefined, fontSize: 24,
      color: '#244b45', fill: kind === 'shape' ? '#f7f3e8' : '#e7b657', imageData,
    };
    commit([...objects, item]);
    setSelectedId(item.id);
  };

  const undo = () => {
    if (!past.length) return;
    setFuture((history) => [objects, ...history]);
    setObjects(past[past.length - 1]);
    setPast((history) => history.slice(0, -1));
  };
  const redo = () => {
    if (!future.length) return;
    setPast((history) => [...history, objects]);
    setObjects(future[0]);
    setFuture((history) => history.slice(1));
  };
  const removeSelected = useCallback(() => {
    if (!selectedId) return;
    commit(objects.filter((item) => item.id !== selectedId));
    setSelectedId('');
  }, [commit, objects, selectedId]);
  const clearOverlays = () => {
    if (!objects.length) return;
    commit([]);
    setSelectedId('');
    setNotice('Belgedeki tüm eklemeler temizlendi.');
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.key === 'Delete' || event.key === 'Backspace') && selectedId && !inputTarget(event.target)) {
        event.preventDefault();
        removeSelected();
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && !inputTarget(event.target)) {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y' && !inputTarget(event.target)) {
        event.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  const pointerStart = (event: ReactPointerEvent<HTMLElement>, item: Overlay, resizing = false) => {
    event.preventDefault();
    event.stopPropagation();
    setSelectedId(item.id);
    const startX = event.clientX;
    const startY = event.clientY;
    const initial = { x: item.x, y: item.y, w: item.w, h: item.h };
    const stage = stageHost.current?.querySelector('.pdf-stage');
    if (!stage) return;
    const bounds = stage.getBoundingClientRect();
    commit(objects);
    const move = (moveEvent: PointerEvent) => {
      const dx = (moveEvent.clientX - startX) / bounds.width;
      const dy = (moveEvent.clientY - startY) / bounds.height;
      if (resizing) {
        updateObject(item.id, { w: Math.max(.035, Math.min(.96 - initial.x, initial.w + dx)), h: Math.max(.035, Math.min(.96 - initial.y, initial.h + dy)) }, false);
      } else {
        updateObject(item.id, { x: Math.max(0, Math.min(1 - initial.w, initial.x + dx)), y: Math.max(0, Math.min(1 - initial.h, initial.y + dy)) }, false);
      }
    };
    const finish = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', finish);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', finish, { once: true });
  };

  const exportPdf = async () => {
    if (!file || !objects.length) return;
    setExporting(true);
    setError('');
    setNotice('');
    try {
      const { PDFDocument, rgb } = await import('pdf-lib');
      const pdf = await PDFDocument.load(await file.arrayBuffer());
      for (const item of objects) {
        const page = pdf.getPage(item.page);
        const { width, height } = page.getSize();
        const rotation = page.getRotation().angle;
        const pos = exportPosition(item, width, height, rotation);
        if (item.kind === 'shape') {
          const fill = colorRgb(item.fill);
          page.drawRectangle({ x: pos.x, y: pos.y, width: pos.width, height: pos.height, color: rgb(fill.r, fill.g, fill.b), borderColor: rgb(fill.r, fill.g, fill.b) });
        } else if (item.kind === 'image' && item.imageData) {
          const bytes = dataUrlBytes(item.imageData);
          const image = item.imageData.startsWith('data:image/png') ? await pdf.embedPng(bytes) : await pdf.embedJpg(bytes);
          page.drawImage(image, { x: pos.x, y: pos.y, width: pos.width, height: pos.height });
        } else if (item.kind === 'text') {
          const png = rasterizeText(item, width, height);
          const image = await pdf.embedPng(dataUrlBytes(png));
          page.drawImage(image, { x: pos.x, y: pos.y, width: pos.width, height: pos.height });
        }
      }
      const output = new Blob([new Uint8Array(await pdf.save())], { type: 'application/pdf' });
      const url = URL.createObjectURL(output);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `${file.name.replace(/\.pdf$/i, '')}-duzenlenmis.pdf`;
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
      setNotice('Yeni PDF indirildi. Eklemeler sayfalara düzleştirilerek işlendi.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'PDF dışa aktarılamadı.');
    } finally {
      setExporting(false);
    }
  };

  const chooseFile = (next: File | undefined) => {
    if (!next) return;
    if (next.type !== 'application/pdf' && !next.name.toLowerCase().endsWith('.pdf')) {
      setError('Lütfen geçerli bir PDF dosyası seç.');
      return;
    }
    setFile(next);
    setObjects([]);
    setPast([]);
    setFuture([]);
    setSelectedId('');
    setError('');
    setNotice('');
  };
  const chooseImage = async (next: File | undefined) => {
    if (!next) return;
    if (!['image/png', 'image/jpeg'].includes(next.type)) {
      setError('Görsel eklemek için JPG veya PNG seç.');
      return;
    }
    const imageData = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('Görsel okunamadı.'));
      reader.onerror = () => reject(new Error('Görsel okunamadı.'));
      reader.readAsDataURL(next);
    });
    addObject('image', imageData);
  };

  return <section className="pdf-editor" data-testid="editor-pdf-canvas" aria-label="Görsel PDF düzenleyici">
    <header className="pdf-editor-head">
      <div className="pdf-editor-title">
        <span className="pdf-editor-mark"><FilePlus2 size={20} /></span>
        <div><div className="pdf-editor-kicker">YEREL PDF STÜDYOSU</div><h3>PDF’ini görsel olarak düzenle</h3>
          <p>Sayfaya metin, kapatma alanı ve görsel ekle. Mevcut PDF metni yeniden yazılamaz; üstünü kapatıp üzerine yeni içerik koyabilirsin.</p>
        </div>
      </div>
      <Button onClick={exportPdf} disabled={!file || exporting || !objects.length} testId="button-pdf-editor-export">
        <Download size={15} />{exporting ? 'PDF hazırlanıyor…' : 'Yeni PDF indir'}
      </Button>
    </header>
    <div className="pdf-editor-toolbar" role="toolbar" aria-label="PDF düzenleme araçları">
      <label className="file-picker" data-testid="input-pdf-editor-file-label"><input ref={fileInput} type="file" accept="application/pdf,.pdf" aria-label="Düzenlenecek PDF’yi aç" data-testid="input-pdf-editor-file" onChange={(event) => chooseFile(event.target.files?.[0])} /><span className="file-plus">+</span>{file ? 'Başka PDF aç' : 'PDF aç'}</label>
      <div className="pdf-tool-group" aria-label="Nesne ekle">
        <button className="pdf-tool-button" onClick={() => addObject('text')} disabled={!file} title="Metin ekle" aria-label="Metin ekle" data-testid="button-pdf-add-text"><Type size={15} />Metin</button>
        <button className="pdf-tool-button" onClick={() => addObject('shape')} disabled={!file} title="Kapatma alanı ekle" aria-label="Kapatma alanı ekle" data-testid="button-pdf-add-shape"><RectangleHorizontal size={15} />Şekil</button>
        <button className="pdf-tool-button" onClick={() => imageInput.current?.click()} disabled={!file} title="Görsel ekle" aria-label="Görsel ekle" data-testid="button-pdf-add-image"><ImagePlus size={15} />Görsel</button>
        <input ref={imageInput} className="pdf-upload-input" type="file" accept="image/png,image/jpeg" aria-label="Eklenecek JPG veya PNG görseli seç" data-testid="input-pdf-editor-image" onChange={(event) => { void chooseImage(event.target.files?.[0]).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : 'Görsel eklenemedi.')); event.currentTarget.value = ''; }} />
      </div>
      <div className="pdf-tool-group" aria-label="Geçmiş">
        <button className="pdf-tool-button" onClick={undo} disabled={!past.length} title="Geri al" aria-label="Geri al" data-testid="button-pdf-undo"><Undo2 size={15} /></button>
        <button className="pdf-tool-button" onClick={redo} disabled={!future.length} title="Yinele" aria-label="Yinele" data-testid="button-pdf-redo"><Redo2 size={15} /></button>
        <button className="pdf-tool-button" onClick={clearOverlays} disabled={!objects.length} title="Tüm eklemeleri temizle" aria-label="Tüm eklemeleri temizle" data-testid="button-pdf-clear"><RotateCcw size={14} /><span>Temizle</span></button>
      </div>
      <div className="pdf-tool-group" aria-label="Yakınlaştırma">
        <button className="pdf-tool-button" onClick={() => setZoom((value) => Math.max(.5, +(value - .1).toFixed(2)))} disabled={!file || zoom <= .5} title="Uzaklaştır" aria-label="Uzaklaştır" data-testid="button-pdf-zoom-out"><Minus size={14} /></button>
        <span className="pdf-page-count" data-testid="text-pdf-zoom">{Math.round(zoom * 100)}%</span>
        <button className="pdf-tool-button" onClick={() => setZoom((value) => Math.min(2.2, +(value + .1).toFixed(2)))} disabled={!file || zoom >= 2.2} title="Yakınlaştır" aria-label="Yakınlaştır" data-testid="button-pdf-zoom-in"><Plus size={14} /></button>
      </div>
    </div>
    {error && <div className="pdf-error"><Status message={error} kind="error" /></div>}
    {notice && <div className="pdf-error"><Status message={notice} kind="success" /></div>}
    <div className="pdf-editor-body">
      <div className="pdf-canvas-area">
        <div className="pdf-stage-wrap" ref={stageHost} data-testid="stage-pdf-canvas">
          {!file && !loading && <div className="pdf-empty"><span className="pdf-empty-icon"><FilePlus2 size={22} /></span><b>Bir PDF ile başlayalım</b><span>Dosya yalnızca bu tarayıcıda açılır. Sayfalarına metin, şekil veya görsel yerleştir.</span><Button onClick={() => fileInput.current?.click()} variant="secondary" testId="button-pdf-editor-open-empty">PDF seç</Button></div>}
          {file && <div className="pdf-stage" style={{ width: stageHeight ? `${Math.min(stageWidth, 920) * zoom}px` : 'min(100%, 700px)', height: stageHeight ? `${stageHeight}px` : 'auto' }} data-testid="canvas-pdf-page">
            <canvas ref={canvasRef} aria-label={`PDF sayfa ${pageIndex + 1}`} />
            <div className="pdf-overlay" onPointerDown={() => setSelectedId('')}>
              {pageObjects.map((item) => <div key={item.id} className={`pdf-object${selectedId === item.id ? ' selected' : ''}`} style={{ left: `${item.x * 100}%`, top: `${item.y * 100}%`, width: `${item.w * 100}%`, height: `${item.h * 100}%`, background: item.kind === 'shape' ? item.fill : 'transparent', color: item.color }} onPointerDown={(event) => pointerStart(event, item)} role="button" tabIndex={0} aria-label={`${item.kind === 'text' ? 'Metin' : item.kind === 'shape' ? 'Şekil' : 'Görsel'} nesnesi`} data-testid={`object-pdf-${item.kind}-${item.id}`}>
                {item.kind === 'text' && <div className="pdf-object-text" style={{ fontSize: `clamp(8px, ${((item.fontSize || 24) / Math.max(pageDimensions.width, 1)) * 100}cqw, 64px)`, color: item.color }}>{item.text}</div>}
                {item.kind === 'image' && item.imageData && <img src={item.imageData} alt="PDF sayfasına eklenen görsel" />}
                {selectedId === item.id && <span className="pdf-resize-handle" role="button" tabIndex={0} aria-label="Nesneyi yeniden boyutlandır" onPointerDown={(event) => pointerStart(event, item, true)} data-testid="handle-pdf-resize" />}
              </div>)}
            </div>
            {loading && <div className="pdf-loading" role="status">Sayfa yükleniyor…</div>}
          </div>}
        </div>
        {file && <div className="pdf-pagebar">
          <button onClick={() => { setPageIndex((index) => Math.max(0, index - 1)); setSelectedId(''); }} disabled={pageIndex <= 0 || loading} aria-label="Önceki sayfa" data-testid="button-pdf-page-prev"><ChevronLeft size={16} /></button>
          <span className="pdf-page-count" data-testid="text-pdf-page-count">Sayfa {pageIndex + 1} / {pageCount || '…'}</span>
          <button onClick={() => { setPageIndex((index) => Math.min(pageCount - 1, index + 1)); setSelectedId(''); }} disabled={pageIndex >= pageCount - 1 || loading} aria-label="Sonraki sayfa" data-testid="button-pdf-page-next"><ChevronRight size={16} /></button>
        </div>}
      </div>
      <aside className="pdf-editor-sidebar" aria-label="Seçili nesne özellikleri">
        <div className="pdf-sidebar-label">SEÇİLİ NESNE</div>
        {!selected ? <div className="pdf-sidebar-empty">{file ? 'Düzenlemek için sayfadaki bir nesneyi seç veya araç çubuğundan yenisini ekle.' : 'PDF açıldığında düzenleme kontrolleri burada görünür.'}</div> : <>
          <div className="pdf-selected-name">{selected.kind === 'text' ? 'Metin katmanı' : selected.kind === 'shape' ? 'Kapatma şekli' : 'Görsel katmanı'}</div>
          {selected.kind === 'text' && <>
            <label className="field"><span>Metin</span><textarea value={selected.text || ''} onChange={(event) => updateObject(selected.id, { text: event.target.value })} aria-label="Seçili metni düzenle" data-testid="input-pdf-object-text" /></label>
            <label className="field"><span>Yazı boyutu <b>{selected.fontSize || 24} pt</b></span><input type="range" min="10" max="52" value={selected.fontSize || 24} onChange={(event) => updateObject(selected.id, { fontSize: Number(event.target.value) })} aria-label="Yazı boyutu" data-testid="input-pdf-font-size" /></label>
          </>}
          {selected.kind !== 'image' && <div className="pdf-color-row">
            <label className="pdf-color-control"><input type="color" value={selected.kind === 'shape' ? selected.fill : selected.color} onChange={(event) => updateObject(selected.id, selected.kind === 'shape' ? { fill: event.target.value } : { color: event.target.value })} aria-label={selected.kind === 'shape' ? 'Şekil dolgu rengi' : 'Metin rengi'} data-testid={selected.kind === 'shape' ? 'input-pdf-shape-fill' : 'input-pdf-object-color'} />{selected.kind === 'shape' ? 'Dolgu rengi' : 'Metin rengi'}</label>
          </div>}
          <Button variant="quiet" onClick={removeSelected} testId="button-pdf-delete-selected"><X size={14} /> Seçili nesneyi sil</Button>
        </>}
        <div className="pdf-editor-notice">PDF’in mevcut yazıları değişmez. Yeni metin, görsel ve şekiller indirdiğin PDF sayfasına düzleştirilir; sonradan ayrı ayrı düzenlenemez.</div>
      </aside>
    </div>
  </section>;
}
