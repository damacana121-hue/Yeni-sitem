import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { QrCode, Download, Link2, MessageSquareText } from 'lucide-react';
import { Button, Status, ToolCard } from './shared';

export function QrTool() {
  const [value, setValue] = useState('https://');
  const [dataUrl, setDataUrl] = useState('');
  const [error, setError] = useState('');
  const [size, setSize] = useState('320');
  const [dark, setDark] = useState('#193f3b');
  const [light, setLight] = useState('#f8f4e9');
  useEffect(() => {
    let cancelled = false;
    if (!value.trim()) { setDataUrl(''); setError(''); return; }
    QRCode.toDataURL(value, { width: Number(size), margin: 2, errorCorrectionLevel: 'M', color: { dark, light } })
      .then((url) => { if (!cancelled) { setDataUrl(url); setError(''); } })
      .catch(() => { if (!cancelled) { setDataUrl(''); setError('QR kodu oluşturulamadı. İçeriği kısaltıp tekrar dene.'); } });
    return () => { cancelled = true; };
  }, [value, size, dark, light]);
  return <section className="category-block" data-testid="section-qr-tool">
    <div className="category-title"><span className="category-number">03</span><div><h3>QR kodu üret</h3><p>Bağlantı, metin ya da iletişim bilgisini anında taranabilir koda çevir.</p></div><span className="category-tag">PAYLAŞ</span></div>
    <ToolCard title="Kendi kodunu oluştur" description="Önizleme her değişiklikte güncellenir · içerik yalnızca cihazında kalır" icon={<QrCode size={17} />} className="qr-card">
      <div className="qr-layout">
        <div className="qr-fields">
          <label className="field"><span>QR içeriği</span><textarea value={value} onChange={(e) => setValue(e.target.value)} rows={4} placeholder="Bir bağlantı veya metin yaz…" data-testid="input-qr-content" /></label>
          <div className="qr-tip"><Link2 size={14} /><span>Bağlantılar için <b>https://</b> dâhil etmeyi unutma.</span></div>
          <div className="qr-options">
            <label className="field"><span>Piksel boyutu</span><select value={size} onChange={(e) => setSize(e.target.value)} data-testid="select-qr-size"><option value="240">240 px</option><option value="320">320 px</option><option value="480">480 px</option><option value="640">640 px</option></select></label>
            <label className="field color-field"><span>Kod rengi</span><input type="color" value={dark} onChange={(e) => setDark(e.target.value)} aria-label="QR kodu rengi" data-testid="input-qr-dark" /></label>
            <label className="field color-field"><span>Zemin rengi</span><input type="color" value={light} onChange={(e) => setLight(e.target.value)} aria-label="QR zemin rengi" data-testid="input-qr-light" /></label>
          </div>
          <div className="qr-content-count"><MessageSquareText size={13} /> {new TextEncoder().encode(value).length} bayt içerik</div>
        </div>
        <div className="qr-preview-column"><div className="qr-paper" data-testid="preview-qr">{dataUrl ? <img src={dataUrl} alt="Oluşturulan QR kod önizlemesi" /> : <div className="qr-placeholder"><QrCode size={42} /><span>Metin girerek başla</span></div>}</div>
          {dataUrl && <a className="button button-dark qr-download" href={dataUrl} download="arac-kutusu-qr.png" data-testid="button-qr-download"><Download size={15} /> PNG indir</a>}
          {error && <Status message={error} kind="error" />}
        </div>
      </div>
    </ToolCard>
  </section>;
}
