import { useEffect, useMemo, useState } from 'react';
import { Braces, Binary, Link, Fingerprint, Palette, AlignLeft, Copy, RefreshCw, Check } from 'lucide-react';
import { Button, Status, ToolCard } from './shared';

type DevTab = 'json' | 'base64' | 'url' | 'uuid' | 'color' | 'counter';
const tabs: { id: DevTab; title: string; icon: typeof Braces }[] = [
  { id: 'json', title: 'JSON', icon: Braces }, { id: 'base64', title: 'Base64', icon: Binary }, { id: 'url', title: 'URL', icon: Link },
  { id: 'uuid', title: 'UUID', icon: Fingerprint }, { id: 'color', title: 'Renk', icon: Palette }, { id: 'counter', title: 'Metin sayacı', icon: AlignLeft },
];
function fromHex(hex: string): [number, number, number] {
  const clean = hex.trim().replace(/^#/, '');
  if (!/^[\da-f]{3}([\da-f]{3})?$/i.test(clean)) throw new Error('HEX değeri #RRGGBB biçiminde olmalı.');
  const full = clean.length === 3 ? clean.split('').map((v) => v + v).join('') : clean;
  return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)];
}
function rgbToHsl([r0, g0, b0]: number[]) {
  const r = r0 / 255, g = g0 / 255, b = b0 / 255; const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0; const l = (max + min) / 2;
  if (max !== min) { const d = max - min; s = l > .5 ? d / (2 - max - min) : d / (max + min); switch (max) { case r: h = (g - b) / d + (g < b ? 6 : 0); break; case g: h = (b - r) / d + 2; break; default: h = (r - g) / d + 4; } h /= 6; }
  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}
function rgbToHex(r: number, g: number, b: number) { return `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`; }
function hslToRgb([h, s0, l0]: number[]): [number, number, number] {
  const s = s0 / 100, l = l0 / 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
  return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
}
function uuid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : r & 3 | 8).toString(16); });
}
export function DeveloperTools() {
  const [tab, setTab] = useState<DevTab>('json');
  const [json, setJson] = useState('{\n  "araç": "Araç Kutusu",\n  "hızlı": true\n}');
  const [counterText, setCounterText] = useState('');
  const [jsonOutput, setJsonOutput] = useState('');
  const [jsonError, setJsonError] = useState('');
  const [baseText, setBaseText] = useState('Merhaba, dünya!');
  const [baseOutput, setBaseOutput] = useState('');
  const [baseMode, setBaseMode] = useState<'encode' | 'decode'>('encode');
  const [urlText, setUrlText] = useState('Araç kutusu / deneme?');
  const [urlOutput, setUrlOutput] = useState('');
  const [urlMode, setUrlMode] = useState<'encode' | 'decode'>('encode');
  const [uuidValue, setUuidValue] = useState('');
  const [hex, setHex] = useState('#2f7369');
  const [rgbText, setRgbText] = useState('47, 115, 105');
  const [hslText, setHslText] = useState('171, 42%, 32%');
  const [colorError, setColorError] = useState('');
  const [copyMessage, setCopyMessage] = useState('');
  const color = useMemo(() => {
    try { const values = fromHex(hex); const hsl = rgbToHsl(values); return { valid: true, values, hsl, hex: rgbToHex(values[0], values[1], values[2]) }; }
    catch { return { valid: false, values: [0, 0, 0], hsl: [0, 0, 0], hex: hex }; }
  }, [hex]);
  useEffect(() => {
    if (color.valid) {
      setRgbText(color.values.join(', '));
      setHslText(`${color.hsl[0]}, ${color.hsl[1]}%, ${color.hsl[2]}%`);
      setColorError('');
    }
  }, [color.hex, color.valid]);
  const count = useMemo(() => ({ words: counterText.split(/\s+/u).filter(Boolean).length, chars: counterText.length, noSpaces: counterText.replace(/\s/g, '').length, lines: counterText ? counterText.split(/\r\n|\r|\n/).length : 0 }), [counterText]);
  const doJson = () => {
    try { const parsed: unknown = JSON.parse(json); setJsonOutput(JSON.stringify(parsed, null, 2)); setJsonError(''); }
    catch (e) { setJsonOutput(''); setJsonError(e instanceof Error ? e.message : 'JSON çözümlenemedi.'); }
  };
  const doBase = () => {
    try {
      if (baseMode === 'encode') { const bytes = new TextEncoder().encode(baseText); let binary = ''; bytes.forEach((b) => binary += String.fromCharCode(b)); setBaseOutput(btoa(binary)); }
      else { const binary = atob(baseText.trim()); const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0)); setBaseOutput(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }
      setBaseError('');
    } catch { setBaseOutput(''); setBaseError('Geçerli Base64 metni çözülemedi. UTF-8 içeriğini ve kodlamayı kontrol et.'); }
  };
  const [baseError, setBaseError] = useState('');
  const doUrl = () => {
    try { setUrlOutput(urlMode === 'encode' ? encodeURIComponent(urlText) : decodeURIComponent(urlText)); setUrlError(''); }
    catch { setUrlOutput(''); setUrlError('URL kodu bozuk veya eksik yüzde kaçışı içeriyor.'); }
  };
  const [urlError, setUrlError] = useState('');
  const copy = async (text: string) => {
    try { await navigator.clipboard.writeText(text); setCopyMessage('Panoya kopyalandı.'); setTimeout(() => setCopyMessage(''), 1800); }
    catch { setCopyMessage('Pano erişimi yok. Metni seçip kopyalayabilirsin.'); }
  };
  const renderTab = () => {
    switch (tab) {
      case 'json': return <div className="dev-pane"><div className="dev-intro"><b>JSON biçimlendir ve doğrula</b><span>Girintile, sözdizimini kontrol et, sonucu kopyala.</span></div><label className="field"><span>JSON metni</span><textarea className="code-area" value={json} onChange={(e) => setJson(e.target.value)} spellCheck={false} data-testid="input-json" /></label><div className="button-pair"><Button onClick={doJson} testId="button-json-format"><Braces size={15} /> Biçimlendir ve doğrula</Button>{jsonOutput && <Button variant="quiet" onClick={() => copy(jsonOutput)} testId="button-json-copy"><Copy size={14} /> Kopyala</Button>}</div>{jsonError && <Status message={`Geçersiz JSON: ${jsonError}`} kind="error" />}{jsonOutput && <pre className="code-output" data-testid="output-json">{jsonOutput}</pre>}</div>;
      case 'base64': return <div className="dev-pane"><div className="dev-intro"><b>Base64 kodla veya çöz</b><span>Türkçe karakterler UTF-8 ile doğru işlenir.</span></div><div className="segmented"><button className={baseMode === 'encode' ? 'selected' : ''} onClick={() => setBaseMode('encode')} data-testid="button-base64-encode">Kodla</button><button className={baseMode === 'decode' ? 'selected' : ''} onClick={() => setBaseMode('decode')} data-testid="button-base64-decode">Çöz</button></div><label className="field"><span>{baseMode === 'encode' ? 'Düz metin' : 'Base64 metni'}</span><textarea value={baseText} onChange={(e) => setBaseText(e.target.value)} data-testid="input-base64" /></label><Button onClick={doBase} testId="button-base64-run"><Binary size={15} /> {baseMode === 'encode' ? 'Base64’e kodla' : 'Metne dönüştür'}</Button>{baseError && <Status message={baseError} kind="error" />}{baseOutput && <ResultBox value={baseOutput} onCopy={copy} testId="output-base64" />}</div>;
      case 'url': return <div className="dev-pane"><div className="dev-intro"><b>URL kodla veya çöz</b><span>Bağlantı parçalarındaki özel karakterleri dönüştür.</span></div><div className="segmented"><button className={urlMode === 'encode' ? 'selected' : ''} onClick={() => setUrlMode('encode')} data-testid="button-url-encode">Kodla</button><button className={urlMode === 'decode' ? 'selected' : ''} onClick={() => setUrlMode('decode')} data-testid="button-url-decode">Çöz</button></div><label className="field"><span>Metin</span><textarea value={urlText} onChange={(e) => setUrlText(e.target.value)} data-testid="input-url" /></label><Button onClick={doUrl} testId="button-url-run"><Link size={15} /> {urlMode === 'encode' ? 'URL kodla' : 'URL çöz'}</Button>{urlError && <Status message={urlError} kind="error" />}{urlOutput && <ResultBox value={urlOutput} onCopy={copy} testId="output-url" />}</div>;
      case 'uuid': return <div className="dev-pane uuid-pane"><div className="dev-intro"><b>UUID v4 üretici</b><span>Rastgele, yerel olarak oluşturulan tanımlayıcı.</span></div><div className="uuid-display mono" data-testid="output-uuid">{uuidValue || 'Üret’e dokun'}</div><div className="button-pair"><Button onClick={() => setUuidValue(uuid())} testId="button-uuid-generate"><RefreshCw size={15} /> UUID üret</Button>{uuidValue && <Button variant="quiet" onClick={() => copy(uuidValue)} testId="button-uuid-copy"><Copy size={14} /> Kopyala</Button>}</div></div>;
      case 'color': return <div className="dev-pane"><div className="dev-intro"><b>HEX · RGB · HSL dönüştürücü</b><span>HEX, RGB ya da HSL değerlerinden birini değiştir.</span></div><div className="color-converter"><div className="color-preview" style={{ background: color.valid ? color.hex : '#e9e3d7' }}><input aria-label="Renk seçici" type="color" value={color.valid ? color.hex : '#000000'} onChange={(e) => setHex(e.target.value)} data-testid="input-color-picker" /></div><div className="color-fields"><label className="field"><span>HEX</span><input value={hex} onChange={(e) => setHex(e.target.value)} data-testid="input-color-hex" /></label><label className="field"><span>RGB</span><input value={rgbText} onChange={(e) => { const text = e.target.value; setRgbText(text); const nums = text.split(/[,\s]+/).filter(Boolean).map(Number); if (nums.length === 3 && nums.every((n) => Number.isInteger(n) && n >= 0 && n <= 255)) { setHex(rgbToHex(nums[0], nums[1], nums[2])); setColorError(''); } else setColorError('RGB için 0–255 arasında üç tam sayı gir.'); }} data-testid="input-color-rgb" /></label><label className="field"><span>HSL</span><input value={hslText} onChange={(e) => { const text = e.target.value; setHslText(text); const nums = text.replaceAll('%', '').split(/[,\s]+/).filter(Boolean).map(Number); if (nums.length === 3 && nums.every(Number.isFinite) && nums[0] >= 0 && nums[0] <= 360 && nums[1] >= 0 && nums[1] <= 100 && nums[2] >= 0 && nums[2] <= 100) { const [r, g, b] = hslToRgb(nums); setHex(rgbToHex(r, g, b)); setColorError(''); } else setColorError('HSL için ton 0–360°, doygunluk ve açıklık 0–100% aralığında olmalı.'); }} data-testid="input-color-hsl" /></label></div></div>{(!color.valid || colorError) && <Status message={colorError || 'Geçerli HEX rengi gir.'} kind="error" />}</div>;
      case 'counter': return <div className="dev-pane"><div className="dev-intro"><b>Canlı metin sayacı</b><span>Kelime, karakter ve satır sayısını anında gör.</span></div><label className="field"><span>Metnin</span><textarea className="count-area" value={counterText} onChange={(e) => setCounterText(e.target.value)} placeholder="Metnini buraya yaz…" data-testid="input-counter-text" /></label><div className="counter-stats">{[['Kelime', count.words], ['Karakter', count.chars], ['Boşluksuz', count.noSpaces], ['Satır', count.lines]].map(([label, value]) => <div key={label} className="counter-stat"><span>{label}</span><b className="mono" data-testid={`count-${String(label).toLocaleLowerCase('tr')}`}>{value}</b></div>)}</div></div>;
    }
  };
  return <section className="category-block" data-testid="section-developer-tools">
    <div className="category-title"><span className="category-number">04</span><div><h3>Yazılımcı Araç Kutusu</h3><p>Kısa işler için yeni sekme açma. Metinlerin tarayıcından çıkmaz.</p></div><span className="category-tag">GELİŞTİRİCİ</span></div>
    <ToolCard title="Günlük kod yardımcıları" description="Küçük dönüştürmeler, hızlı kontroller" icon={<Braces size={17} />} className="developer-card">
      <div className="dev-layout"><div className="dev-tabs" role="tablist" aria-label="Yazılımcı araçları">{tabs.map(({ id, title, icon: Icon }) => <button className={`dev-tab ${tab === id ? 'active' : ''}`} onClick={() => setTab(id)} key={id} role="tab" aria-selected={tab === id} data-testid={`tab-dev-${id}`}><Icon size={16} /><span>{title}</span></button>)}</div><div className="dev-main" role="tabpanel">{renderTab()}</div></div>
      {copyMessage && <div className="copy-feedback" role="status" data-testid="status-copy"><Check size={13} />{copyMessage}</div>}
    </ToolCard>
  </section>;
}
function ResultBox({ value, onCopy, testId }: { value: string; onCopy: (value: string) => void; testId: string }) {
  return <div className="result-box"><pre data-testid={testId}>{value}</pre><button aria-label="Sonucu kopyala" onClick={() => onCopy(value)} data-testid={`button-copy-${testId}`}><Copy size={15} /></button></div>;
}
