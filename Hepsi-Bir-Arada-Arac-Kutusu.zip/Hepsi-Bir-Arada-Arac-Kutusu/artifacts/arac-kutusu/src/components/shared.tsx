import { type ReactNode } from 'react';
import { Check, AlertCircle, Download, LoaderCircle } from 'lucide-react';

export function ToolCard({ title, description, icon, children, className = '' }: { title: string; description: string; icon: ReactNode; children: ReactNode; className?: string }) {
  return <article className={`tool-card ${className}`}><div className="tool-card-head"><span className="tool-icon">{icon}</span><div><h3>{title}</h3><p>{description}</p></div></div><div className="tool-card-body">{children}</div></article>;
}
export function Status({ message, kind = 'success' }: { message: string; kind?: 'success' | 'error' | 'working' }) {
  const Icon = kind === 'success' ? Check : kind === 'error' ? AlertCircle : LoaderCircle;
  return <div className={`status-message ${kind}`} role={kind === 'error' ? 'alert' : 'status'} data-testid={`status-${kind}`}><Icon size={15} className={kind === 'working' ? 'spin' : ''} />{message}</div>;
}
export function DownloadLink({ href, name, label = 'İndir' }: { href: string; name: string; label?: string }) {
  return <a className="button button-dark" href={href} download={name} data-testid={`link-download-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}><Download size={15} />{label}</a>;
}
export function FilePicker({ accept, multiple = false, onChange, label = 'Dosya seç' }: { accept: string; multiple?: boolean; onChange: (files: FileList | null) => void; label?: string }) {
  return <label className="file-picker"><input type="file" accept={accept} multiple={multiple} onChange={(e) => onChange(e.target.files)} aria-label={label} data-testid={`input-file-${label.toLocaleLowerCase('tr').replaceAll(' ', '-')}`} /><span className="file-plus">+</span><span>{label}</span></label>;
}
export function Button({ children, onClick, disabled, variant = 'primary', testId, type = 'button' }: { children: ReactNode; onClick?: () => void; disabled?: boolean; variant?: 'primary' | 'secondary' | 'quiet'; testId?: string; type?: 'button' | 'submit' }) {
  return <button type={type} className={`button button-${variant}`} onClick={onClick} disabled={disabled} data-testid={testId}>{children}</button>;
}
export function TextInput(props: { label: string; value: string | number; onChange: (value: string) => void; type?: string; placeholder?: string; min?: number; max?: number; step?: number; testId?: string }) {
  const { label, value, onChange, type = 'text', placeholder, min, max, step, testId } = props;
  return <label className="field"><span>{label}</span><input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} min={min} max={max} step={step} data-testid={testId} /></label>;
}
