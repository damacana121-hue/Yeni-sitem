import { useEffect, useMemo, useRef, useState } from 'react';
import { Image, FileText, Code2, QrCode, Search, ShieldCheck, Menu, X, ArrowUpRight, Wrench, Sparkles } from 'lucide-react';
import { ImageTools } from './components/ImageTools';
import { FileTools } from './components/FileTools';
import { DeveloperTools } from './components/DeveloperTools';
import { QrTool } from './components/QrTool';

type Section = 'genel' | 'gorsel' | 'dosya' | 'qr' | 'yazilim';
const sections: { id: Section; label: string; icon: typeof Image; desc: string }[] = [
  { id: 'genel', label: 'Araçlara göz at', icon: Wrench, desc: 'Tüm pratik araçlar' },
  { id: 'gorsel', label: 'Görsel araçları', icon: Image, desc: 'Düzenle, dönüştür, sıkıştır' },
  { id: 'dosya', label: 'Dosya araçları', icon: FileText, desc: 'PDF ve belge işlemleri' },
  { id: 'qr', label: 'QR kodu üret', icon: QrCode, desc: 'İçeriğini koda dönüştür' },
  { id: 'yazilim', label: 'Yazılımcı araçları', icon: Code2, desc: 'Kodla ilgili küçük işler' },
];
const searchTerms: Record<Exclude<Section, 'genel'>, string> = {
  gorsel: 'görsel image fotoğraf boyutlandır kırp avatar daire şeffaf arka plan temizleme sıkıştır dönüştür jpg png webp metadata',
  dosya: 'dosya pdf docx belge word görsel sayfa birleştir ayır sıkıştır metin not annotation görüntü dönüştür çıkar',
  qr: 'qr kod karekod bağlantı url metin indir png üret',
  yazilim: 'yazılımcı json format doğrula base64 encode decode url uuid hex rgb hsl renk metin kelime karakter say satır',
};

function App() {
  const [section, setSection] = useState<Section>('genel');
  const [query, setQuery] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const selected = sections.find((item) => item.id === section)!;
  const matchingSection = (id: Exclude<Section, 'genel'>) => !query.trim() || `${sections.find((item) => item.id === id)?.label} ${searchTerms[id]}`.toLocaleLowerCase('tr').includes(query.trim().toLocaleLowerCase('tr'));
  const searchMatches = useMemo(() => !query.trim() || section === 'genel'
    ? !query.trim() || (Object.keys(searchTerms) as Exclude<Section, 'genel'>[]).some((id) => matchingSection(id))
    : matchingSection(section), [query, section]);
  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); searchRef.current?.focus(); }
      if (event.key === 'Escape' && document.activeElement === searchRef.current) { setQuery(''); searchRef.current?.blur(); }
    };
    window.addEventListener('keydown', shortcut); return () => window.removeEventListener('keydown', shortcut);
  }, []);
  const jump = (id: Section) => { setSection(id); setMobileOpen(false); document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); };

  return <div className="app-shell">
    <div className="noise" aria-hidden="true" />
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><Wrench size={20} strokeWidth={2.5} /></div>
        <div><div className="brand-name">araç kutusu<span>.</span></div><div className="brand-caption">GÜNLÜK DİJİTAL İŞLER</div></div>
        <button className="mobile-close" aria-label="Menüyü kapat" onClick={() => setMobileOpen(false)} data-testid="button-close-menu"><X size={18} /></button>
      </div>
      <div className="side-label">ÇALIŞMA ALANI</div>
      <nav className="nav-list" aria-label="Araç kategorileri">
        {sections.map(({ id, label, icon: Icon, desc }, index) => <button key={id} className={`nav-item ${section === id ? 'active' : ''}`} onClick={() => jump(id)} data-testid={`nav-${id}`}>
          <span className="nav-icon"><Icon size={18} /></span><span className="nav-copy"><b>{label}</b><small>{desc}</small></span>{section === id && <span className="nav-index">0{index + 1}</span>}
        </button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="privacy-tile"><ShieldCheck size={18} /><div><b>Dosyaların sende kalır</b><p>İşlemler bu tarayıcıda yapılır. Sunucuya yükleme yok.</p></div></div>
        <div className="side-foot"><span className="status-dot" /> Tamamen yerel <span>·</span> Ücretsiz</div>
      </div>
    </aside>
    {mobileOpen && <button className="scrim" aria-label="Menüyü kapat" onClick={() => setMobileOpen(false)} data-testid="button-close-menu-scrim" />}
    <main className="main-area">
      <header className="topbar">
        <button className="menu-button" aria-label="Menüyü aç" onClick={() => setMobileOpen(true)} data-testid="button-menu"><Menu size={20} /></button>
        <div className="crumb"><span>Çalışma alanı</span><span className="crumb-slash">/</span><b>{selected.label}</b></div>
        <div className="top-actions"><label className="search-box"><Search size={16} /><input ref={searchRef} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Araçlarda ara…" aria-label="Araçlarda ara" data-testid="input-search" /><kbd>⌘ K</kbd></label><span className="local-pill"><span className="status-dot" /> YEREL İŞLEM</span></div>
      </header>
      <div className="page-content">
        <section className="intro">
          <div className="intro-copy">
            <div className="eyebrow"><Sparkles size={13} /> İŞİNİ HIZLANDIR</div>
            <h1 className="display">Küçük işler,<br /><em>büyük kolaylık.</em></h1>
            <p>Görselini düzenle, dosyanı dönüştür, kodunu kontrol et. Kurulum yok, hesap yok — sadece işini gör.</p>
          </div>
          <div className="intro-art" aria-hidden="true">
            <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" /><div className="art-core"><Wrench size={42} strokeWidth={1.4} /></div>
            <div className="art-chip chip-a"><Image size={16} /></div><div className="art-chip chip-b"><Code2 size={16} /></div><div className="art-chip chip-c"><QrCode size={16} /></div>
            <span className="art-note">04 kategoride<br />12+ araç</span>
          </div>
        </section>
        <section className="workspace" id="workspace">
          <div className="section-heading">
            <div><div className="section-kicker">ARAÇLAR</div><h2 className="display">{section === 'genel' ? 'Neye ihtiyacın var?' : selected.label}</h2></div>
            <span className="section-meta">{section === 'genel' ? '4 kategori · tamamen tarayıcıda' : selected.desc}</span>
          </div>
          {!searchMatches && <div className="empty-search" role="status" data-testid="status-search-empty"><Search size={20} /><b>Bu kategoride eşleşme yok</b><span>Arama ifadesini değiştir veya başka bir kategori seç.</span><button onClick={() => setQuery('')} data-testid="button-search-clear">Aramayı temizle</button></div>}
          {searchMatches && <div className="tool-content fade-up" key={section}>
            {(section === 'genel' || section === 'gorsel') && matchingSection('gorsel') && <ImageTools />}
            {(section === 'genel' || section === 'dosya') && matchingSection('dosya') && <FileTools />}
            {(section === 'genel' || section === 'qr') && matchingSection('qr') && <QrTool />}
            {(section === 'genel' || section === 'yazilim') && matchingSection('yazilim') && <DeveloperTools />}
          </div>}
        </section>
        <footer className="footer"><div className="footer-brand"><span className="mini-mark"><Wrench size={13} /></span> araç kutusu<span className="accent-dot">.</span></div><span>İşlem cihazında kalır. Dosyaların hiçbir yere gönderilmez.</span><a href="#workspace" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} data-testid="link-back-to-top">Başa dön <ArrowUpRight size={13} /></a></footer>
      </div>
    </main>
  </div>;
}

export default App;
